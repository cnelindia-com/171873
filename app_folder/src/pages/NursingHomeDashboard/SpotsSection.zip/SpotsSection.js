import React, { useState, useEffect, useMemo } from "react";
import axios from "axios";
import styled from "styled-components";
import "../../css/theme.css";
import { BaseUrl } from "../../BaseUrl";
import AddSpotPage from "./AddSpotPage";

import {
  MainContent,
} from "./StyledComponents";
// ====== Styled Components ======
const DataTable = styled.div`
  background: var(--color-surface);
  border-radius: 12px;
  box-shadow: 0 2px 10px var(--color-shadow);
  overflow: hidden;
  width: 95%;
  max-width: 1100px;
  margin: 1.5rem auto;
`;

const TableHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: var(--color-primary);
  color: #fff;
  padding: 1rem 1.5rem;
  border-top-left-radius: 12px;
  border-top-right-radius: 12px;
`;

const TableTitle = styled.h2`
  font-size: 1.1rem;
  font-weight: 600;
  margin: 0;
`;

const AddButton = styled.button`
  background: #fff;
  color: var(--color-primary);
  border: 1px solid var(--color-primary);
  font-weight: 600;
  padding: 0.5rem 1.2rem;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.25s ease;

  &:hover {
    background: var(--color-primary);
    color: #fff;
  }
`;

const TableContainer = styled.div`
  width: 100%;
  overflow-x: auto;
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  font-family: var(--font-base);
`;

const TableHead = styled.thead`
  background: var(--color-background);
`;

const TableHeaderCell = styled.th`
  padding: 0.9rem 1rem;
  text-align: left;
  font-weight: 600;
  color: var(--color-text-main);
  border-bottom: 2px solid var(--color-shadow);
`;

const TableBody = styled.tbody`
  background: var(--color-surface);
`;

const TableRow = styled.tr`
  &:nth-child(even) {
    background: rgba(0, 0, 0, 0.03);
  }

  &:hover {
    background: rgba(21, 101, 192, 0.05);
  }
`;

const TableCell = styled.td`
  padding: 0.8rem 1rem;
  color: var(--color-text-main);
  font-size: 0.95rem;
  border-bottom: 1px solid #eee;
`;

const ActionButtons = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const TableButton = styled.button`
  background: transparent;
  border: none;
  font-size: 1.1rem;
  cursor: pointer;
  transition: 0.2s ease;

  &.edit {
    color: var(--color-primary);
    &:hover {
      color: var(--color-primary-dark);
      transform: scale(1.1);
    }
  }

  &.delete {
    color: var(--color-error);
    &:hover {
      color: #b71c1c;
      transform: scale(1.1);
    }
  }

  &.view {
    color: var(--color-accent);
    &:hover {
      color: var(--color-primary);
      transform: scale(1.1);
    }
  }
`;

// ====== Component ======
const SpotsSection = () => {
  const [spots, setSpots] = useState([]);
  const [showAddPage, setShowAddPage] = useState(false);
  const [spotToEdit, setSpotToEdit] = useState(null);
  const [selectedUser, setSelectedUser] = useState("");

  const token = localStorage.getItem("pflegeUserToken");
  const pflegeUserId = localStorage.getItem("pflegeUserId");
  const type = localStorage.getItem("pflegeUsertype");

  /* ================= API ================= */

  // ✅ Fetch Spots
  const fetchSpots = async () => {
    try {
      const res = await axios.get(`${BaseUrl}spots`, {
        params: { user_id: pflegeUserId, usertype: type },
        headers: { Authorization: `Bearer ${token}` },
      });
      setSpots(res.data?.data || []);
    } catch (err) {
      console.error("Fetch spots error:", err);
    }
  };

  // ✅ Delete Spot
  const handleDeleteSpot = async (id) => {
    if (!window.confirm("Spot wirklich löschen?")) return;

    try {
      await axios.delete(`${BaseUrl}deletespot/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchSpots();
    } catch (err) {
      alert("Fehler beim Löschen");
    }
  };

  // ✅ Edit Spot
  const handleEditSpot = (spot) => {
    setSpotToEdit(spot);
    setShowAddPage(true);
  };

  useEffect(() => {
    fetchSpots();
  }, []);

  /* ================= Filter ================= */
  const filteredSpots = useMemo(() => {
    if (!selectedUser) return spots;
    return spots.filter((s) => s.user_id == selectedUser);
  }, [spots, selectedUser]);

  /* ================= Add / Edit Page ================= */
  if (showAddPage) {
    return (
      <AddSpotPage
      editData={spotToEdit}
      onBack={() => {
        setShowAddPage(false);
        setSpotToEdit(null);
        fetchSpots();
      }}
      fetchSpots={fetchSpots}
    />


    );
  }

  /* ================= Table ================= */
  return (
    <MainContent>
      <DataTable>
        <TableHeader>
          <TableTitle>Meine Pflegeplätze</TableTitle>
          <AddButton onClick={() => setShowAddPage(true)}>
            + Neu hinzufügen
          </AddButton>
        </TableHeader>

        <TableContainer>
          <Table>
            <TableHead>
              <tr>
                <TableHeaderCell>Ortsname</TableHeaderCell>
                <TableHeaderCell>Zimmertyp</TableHeaderCell>
                <TableHeaderCell>Preis (€/Monat)</TableHeaderCell>
                <TableHeaderCell>Verfügbarkeit</TableHeaderCell>
                <TableHeaderCell>Status</TableHeaderCell>
                <TableHeaderCell>Planen</TableHeaderCell>
                <TableHeaderCell>Aktion</TableHeaderCell>
              </tr>
            </TableHead>

            <TableBody>
              {filteredSpots.length > 0 ? (
                filteredSpots.map((spot) => (
                  <TableRow key={spot.id}>
                    <TableCell>{spot.name_of_the_place}</TableCell>
                    <TableCell>
                      {spot.room_type === "1"
                        ? "Einzelzimmer"
                        : "Doppelzimmer"}
                    </TableCell>
                    <TableCell>€{spot.price_per_month}</TableCell>
                   <TableCell>
                    {spot.availability == 1 
                      ? "Sofort" 
                      : spot.availability == 2 
                        ? "Kurzfristig" 
                        : spot.availability == 3 
                          ? "1–3 Monate"
                          : "Unbekannt"}
                  </TableCell>

                    <TableCell>
                      {spot.status === "1" ? "Active" : "Inactive"}
                    </TableCell>
                    <TableCell>
                      {spot.plan === "1" ? "Basic" : "PRO"}
                    </TableCell>

                    <TableCell>
                      <ActionButtons>
                        <TableButton
                          className="edit"
                          onClick={() => handleEditSpot(spot)}
                        >
                          ✏️
                        </TableButton>
                        <TableButton
                          className="delete"
                          onClick={() => handleDeleteSpot(spot.id)}
                        >
                          🗑️
                        </TableButton>
                      </ActionButtons>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan="6" style={{ textAlign: "center" }}>
                    Keine Spots vorhanden
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </DataTable>
    </MainContent>
  );
};

export default SpotsSection;
