import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { BaseUrl } from "../BaseUrl";
import {
  PageWrapper,
  TopGrid,
  Gallery,
  MainImage,
  Thumbs,
  Thumb,
  InfoCard,
  Title,
  Address,
  Price,
  Badge,
  CTAButton,
  Section,
  SectionTitle,
} from "./FacilityDetails/DetailsStyles";

export default function FacilityDetails() {
  const { id } = useParams();
  const [facility, setFacility] = useState(null);
  const [activeImg, setActiveImg] = useState(0);

  useEffect(() => {
    axios.get(`${BaseUrl}facility/${id}`).then((res) => {
      setFacility(res.data.data);
    });
  }, [id]);

  if (!facility) return null;

  return (
    <PageWrapper>
      {/* TOP SECTION */}
      <TopGrid>

        {/* LEFT – PHOTO GALLERY */}
        <Gallery>
          <MainImage
            src={
              facility.images?.length
                ? facility.images[activeImg]
                : "../"
            }
          />
          <Thumbs>
            {facility.images?.map((img, i) => (
              <Thumb
                key={i}
                src={img}
                active={i === activeImg}
                onClick={() => setActiveImg(i)}
              />
            ))}
          </Thumbs>
        </Gallery>

        {/* RIGHT – KEY INFO CARD */}
        <InfoCard>
          <Title>{facility.name_of_the_place}</Title>
          <Address>{facility.address}</Address>

          <Price>ab {facility.price_per_month} €/Monat</Price>

          <Badge status={facility.room_type}>
            {facility.room_type === "1"
              ? "Einzelzimmer"
              : facility.room_type === "2"
              ? "Doppelzimmer"
              : "Auf Anfrage"}
          </Badge>

          <CTAButton>Request Inquiry</CTAButton>
          <small>
            No contractual obligation – your inquiry is non-binding
          </small>
        </InfoCard>
      </TopGrid>

      {/* DESCRIPTION */}
      <Section>
        <SectionTitle>Description</SectionTitle>
        <p>{facility.description || "No description available yet."}</p>
      </Section>

      {/* KEY FACTS */}
      <Section>
        <SectionTitle>Key Facts</SectionTitle>
        <ul>
          <li>Care type: {facility.care_level === "1"
              ? "Stufe 1"
              : facility.care_level === "2"
              ? "Stufe 2"
              : facility.care_level === "3"
              ? "Stufe 3"
              : "Keine Angabe"}</li>
          <li>Room type: {facility.room_type === "1"
              ? "Einzelzimmer"
              : facility.room_type === "2"
              ? "Doppelzimmer"
              : "Auf Anfrage"}</li>
          <li>Availability: {facility.availability === "1"
              ? "Sofort"
              : facility.availability === "2"
              ? "Kurzfristig"
              : "1–3 Monate"}</li>
        </ul>
      </Section>

      {/* LOCATION */}
      <Section>
        <SectionTitle>Location</SectionTitle>
        <p>{facility.address}</p>
      </Section>
    </PageWrapper>
  );
}
