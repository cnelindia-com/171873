import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { BaseUrl } from "../BaseUrl";
import {
  Container,
  Title,
  Form,
  SearchHeader,
  Subtitle,
  Row,
  Label,
  Input,
  Select,
  SearchBtn,
  ResultsGrid,
  Card,
  Name,
  Address,
  Detail,
  Details,
  ButtonContainer,
  DetailsBtn,
} from "./Styles";
import Pagination from "./Pagination";

export default function SearchPage() {
  const navigate = useNavigate();
  const openDetail = (facility) => {
    navigate(`/details/${facility.id}`);
  };
  const [results, setResults] = useState([]);
  const [cityList, setCityList] = useState([]);
  const [pagination, setPagination] = useState({
    current_page: 1,
    last_page: 1,
    per_page: 10,
  });
  const [filters, setFilters] = useState({
    postal_code: "",
    city: "",
    distance: "",
    care_level: "",
    room_type: "",
    availability: "",
    lat: null,
    lng: null,
  });

  const [showContact, setShowContact] = useState(false);
  const [contact, setContact] = useState({ name: "", phone: "", msg: "" });
  const [successMsg, setSuccessMsg] = useState("");
  const token = localStorage.getItem("pflegeUserToken");

  // ✅ Get user location
  useEffect(() => {
    navigator.geolocation.getCurrentPosition((position) => {
      setFilters((prev) => ({
        ...prev,
        lat: position.coords.latitude,
        lng: position.coords.longitude,
      }));
    });
  }, []);

  useEffect(() => {
    fetchSpots();
    fetchCities();
  }, []);

  const fetchCities = async () => {
    try {
      const res = await axios.get(`${BaseUrl}cities`);
      setCityList(res.data.data);
    } catch (error) {
      console.log("City fetch error:", error);
    }
  };

  const fetchSpots = async (page = 1) => {
    try {
      const res = await axios.get(`${BaseUrl}allspots?page=${page}`);
      const api = res.data?.data;

      setResults(api.data);
      setPagination({
        current_page: api.current_page,
        last_page: api.last_page,
        per_page: api.per_page,
      });
    } catch (error) {
      console.error("Error fetching spots:", error);
    }
  };

  const handleSearch = async (e, page = 1) => {
    e.preventDefault();
    try {
      if (!filters.lat || !filters.lng) {
        alert("Bitte erlauben Sie den Standortzugriff.");
        return;
      }
      const query = new URLSearchParams({ ...filters, page }).toString();
      const response = await axios.get(`${BaseUrl}search?${query}`);

      const api = response.data.data;
      setResults(api.data);
      setPagination({
        current_page: api.current_page,
        last_page: api.last_page,
        per_page: api.per_page,
      });
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <Container>
        <>
          <SearchHeader>
            <Title>Pflegeheim finden</Title>
            <Subtitle>
              Das passende Heim für Ihre Liebsten – schnell und einfach
            </Subtitle>
          </SearchHeader>

          <Form onSubmit={handleSearch}>
            <Row>
              <div>
                <Label>PLZ</Label>
                <Input
                  placeholder="z.B. 53111"
                  onChange={(e) =>
                    setFilters({ ...filters, postal_code: e.target.value })
                  }
                />
              </div>
              <div>
                <Label>Stadt</Label>
                <Select
                  onChange={(e) =>
                    setFilters({ ...filters, city: e.target.value })
                  }
                >
                  <option value="">Alle</option>
                  {cityList.map((item, index) => (
                    <option key={index} value={item.city}>
                      {item.city}
                    </option>
                  ))}
                </Select>
              </div>
              <div>
                <Label>Entfernung (km)</Label>
                <Input
                  type="number"
                  placeholder="30"
                  onChange={(e) =>
                    setFilters({ ...filters, distance: e.target.value })
                  }
                />
              </div>
            </Row>

            <Row>
              <div>
                <Label>Pflegestufe</Label>
                <Select
                  onChange={(e) =>
                    setFilters({ ...filters, care_level: e.target.value })
                  }
                >
                  <option value="">Alle</option>
                  <option value="1">Stufe 1</option>
                  <option value="2">Stufe 2</option>
                  <option value="3">Stufe 3</option>
                </Select>
              </div>
              <div>
                <Label>Zimmerart</Label>
                <Select
                  onChange={(e) =>
                    setFilters({ ...filters, room_type: e.target.value })
                  }
                >
                  <option value="">Alle</option>
                  <option value="1">Einzelzimmer</option>
                  <option value="2">Doppelzimmer</option>
                </Select>
              </div>
              <div>
                <Label>Verfügbarkeit</Label>
                <Select
                  onChange={(e) =>
                    setFilters({ ...filters, availability: e.target.value })
                  }
                >
                  <option value="">Alle</option>
                  <option value="1">Sofort</option>
                  <option value="2">Kurzfristig</option>
                  <option value="3">1–3 Monate</option>
                </Select>
              </div>
            </Row>
            <SearchBtn type="submit">Suchen</SearchBtn>
          </Form>

          <h2 style={{ color: "var(--color-text-main)", margin: "1.5rem 0" }}>
            {results.length} Einrichtungen gefunden
          </h2>

          <ResultsGrid>
            {results.map((f) => (
              <Card key={f.id}>
                <Name>{f.name_of_the_place}</Name>
                <Address>{f.address}</Address>
                <Details>
                  <Detail>
                    <span>Pflege</span>
                    <strong>
                      {f.care_level
                        ? `Stufe ${f.care_level}`
                        : "Keine Angabe"}
                    </strong>
                  </Detail>
                  <Detail>
                    <span>Zimmer</span>
                    <strong>
                      {f.room_type === "1"
                        ? "Einzelzimmer"
                        : f.room_type === "2"
                        ? "Doppelzimmer"
                        : "-"}
                    </strong>
                  </Detail>
                  <Detail>
                    <span>Verfügbarkeit</span>
                    {f.availability === "1"
                      ? "Sofort"
                      : f.availability === "2"
                      ? "Kurzfristig"
                      : f.availability === "3"
                      ? "1–3 Monate"
                      : "-"}
                  </Detail>
                  <Detail>
                    <span>Preis</span>
                    <strong>{f.price_per_month}</strong>
                  </Detail>
                </Details>
                <ButtonContainer>
                  <DetailsBtn onClick={() => openDetail(f)}>
                    Details anzeigen
                  </DetailsBtn>
                </ButtonContainer>
              </Card>
            ))}
          </ResultsGrid>

          <Pagination
            currentPage={pagination.current_page}
            lastPage={pagination.last_page}
            onPageChange={(page) => fetchSpots(page)}
          />
        </>
    </Container>
  );
}
