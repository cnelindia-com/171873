import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styled from 'styled-components';

const HeaderContainer = styled.header`
  background-color: #2c3e50;
  color: white;
  padding: 1rem 0;
  position: sticky;
  top: 0;
  z-index: 100;
`;

const Nav = styled.nav`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const Logo = styled(Link)`
  font-size: 1.5rem;
  font-weight: bold;
  color: white;
  text-decoration: none;
`;

const NavLinks = styled.div`
  display: flex;
  gap: 2rem;
  align-items: center;
`;

const NavLink = styled(Link)`
  color: white;
  text-decoration: none;
  padding: 0.5rem 1rem;
  border-radius: 4px;
  transition: background-color 0.3s;

  &:hover {
    background-color: #34495e;
  }
`;

const UserInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`;

const UserName = styled.span`
  color: white;
  font-weight: 500;
`;

const LogoutButton = styled.button`
  background-color: #e74c3c;
  color: white;
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s;

  &:hover {
    background-color: #c0392b;
  }
`;

function Header() {
  const navigate = useNavigate();
  const isLoggedIn = localStorage.getItem('pflegeLoggedIn');
  const userName = localStorage.getItem('pflegeUserName');
  // const userType = localStorage.getItem('pflegeUserType');

  const handleLogout = () => {
    localStorage.removeItem('pflegeLoggedIn');
    localStorage.removeItem('pflegeUserEmail');
    localStorage.removeItem('pflegeUserName');
    // localStorage.removeItem('pflegeUserType');
    navigate('/');
  };

  return (
    <HeaderContainer>
      <Nav>
        <Logo to="/">PflegeFinder</Logo>
        <NavLinks>
          {/* <NavLink to="/">Startseite</NavLink> */}
          {/* <NavLink to="/suche">Suche</NavLink> */}
          
          {isLoggedIn ? (
            <>
              {/* <NavLink to="/profil">Mein Profil</NavLink> */}
              
                <NavLink to="/dashboard">Armaturenbrett</NavLink>
              
              <UserInfo>
                <UserName>Hallo, {userName}</UserName>
                <LogoutButton onClick={handleLogout}>Abmelden</LogoutButton>
              </UserInfo>
            </>
          ) : (
            <NavLink to="/login"  state={{login:true  }}>Einloggen</NavLink>
          )}
        </NavLinks>
      </Nav>
    </HeaderContainer>
  );
}

export default Header;